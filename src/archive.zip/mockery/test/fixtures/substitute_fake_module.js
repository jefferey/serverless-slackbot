var foo = function() {
    return 'substitute foo';
};

exports.foo = foo;
