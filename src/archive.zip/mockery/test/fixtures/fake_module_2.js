var bar = function() {
    return 'real bar';
};

exports.bar = bar;
