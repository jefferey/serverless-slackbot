var foo = function() {
    return 'real foo';
};

exports.foo = foo;
